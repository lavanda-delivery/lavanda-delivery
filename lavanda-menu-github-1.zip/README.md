# Lavanda Restoran — Online Menyu

Bu layihə GitHub Pages üçün hazırlanmış sadə, mobil uyğun restoran menyusudur.

## Qurmaq
1. `index.html`, `style.css`, `script.js` fayllarını GitHub repository-yə yükləyin.
2. `script.js` daxilində:
   `const WHATSAPP_NUMBER = "994XXXXXXXXX";`
   hissəsini restoranın WhatsApp nömrəsi ilə dəyişin.
3. GitHub → **Settings → Pages** bölməsində **Deploy from a branch** seçin.
4. Branch olaraq `main`, folder olaraq `/ (root)` seçin.
5. Save edin. GitHub sizə menyunun linkini verəcək.

## Funksiyalar
- Mobil uyğun menyu
- Kateqoriyalar
- Səbətə məhsul əlavə etmə
- Sayı artırıb/azaltma
- Ümumi məbləğin hesablanması
- Ad və ünvan daxil etmə
- WhatsApp-a hazır sifariş göndərilməsi
