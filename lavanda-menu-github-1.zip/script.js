const WHATSAPP_NUMBER = "994XXXXXXXXX"; // <-- Buraya WhatsApp nömrənizi yazın

const menu = [
  {cat:"Səhər yeməkləri", items:[
    ["Səhər yeməkləri 1 nəfər üçün SET",10],
    ["Qlazok",2.5],["Qayğanaq",2.5],["Pomidor yumurta",3.5],["Kükü",3],
    ["Sosiska",3.5],["Sosiska yumurta",4],["Tərəvəzli omlet",3.5]
  ]},
  {cat:"Salatlar", items:[
    ["Pomidor, xiyar",3.5],["Pendir",3],["Süzmə",3],["Qatıq",2],["Turşu assorti",4.5],
    ["Döyməc",3],["Meyvə (mövsümə görə)",10],["Göyərti",3],["Acika",3],["Zeytun",4],
    ["Valdorf salatı",5],["Çoban salatı",4],["Sparja salatı",5],["Rafaello (4 ədəd)",5],
    ["Xırçıldılı Badımcan salatı",5],["Kök salatı",3],["Paytaxt salatı",4],
    ["Mimoza salatı",4.5],["Sezar salatı (toyuqlu)",8],["Yunan salatı",5],
    ["Manqal salatı",5],["Rəngli bibər salatı",5]
  ]},
  {cat:"İsti yeməklər", items:[
    ["Lavanda özəl yemək",7],["Piti",7],["Şobadılı qovurma",5],["Spaghetti (bolonez)",8],
    ["Toyuq langeti",6],["Qaymaqlı Toyuq",8],["Tava",7],["Nar qovurma",9],
    ["Toyuq örüşdə",7],["Dolu dolması",6],["Juliyen sadə",5],["Julien toyuqlu",7],
    ["Julien mal",8],["Kiyev kotleti",7],["Toyuq sote",7],["Toyuq çığırtma (bütöv)",18],
    ["Toyuq Şnitsel",7.5],["Ət Stroqonov",13],["Toyuq Stroqonov",9],
    ["Fettuccine Alfredo",9],["Monastırsayağı toyuq",9]
  ]},
  {cat:"Saclar", items:[
    ["Sac toyuq",20],["Sac Dana",28],["Sac quzu",30],["Sac qarışıq",36]
  ]},
  {cat:"Fast food", items:[
    ["Burger + fri",6.5],["Chicken burger + fri",6.5],["Çizburger + fri",7],
    ["Double burger + fri",9],["Pendir çubuqları + fri",7],["Toyuq çubuqları + fri",6],
    ["Toyuq budu + fri",5],["Club Sandwich + fri",8],["KFC qanadları + fri",6],
    ["Acılı toyuq qanadları+fri",6],["Langet toyuq + fri",7],["Şnitsel toyuq + fri",3.5],
    ["Tost sucuklu + fri",5],["Fri",3],["Nuggets + fri",4.5],["Soğan halqası + fri",5]
  ]},
  {cat:"Xəmir yeməkləri", items:[
    ["Ət Qutabı",1.5],["Göy Qutabı",0.8],["Gürcü Xəngəli 1 ədəd",1],["Girs",3],
    ["Yarpaq Xəngəli",5],["Düşbərə",3]
  ]},
  {cat:"Pizzalar", items:[
    ["Lavanda Pizza",18],["Lavanda kənarı pendirli pizza",18],["Toyuqlu pizza",13],
    ["Pizza göbələk",11],["Pepperoni",13],["Margherita",10],["Qapalı pizza",13],
    ["Sosisli pizza",12],["Qiymalı pizza",15],["Qarışıq pizza",17]
  ]},
  {cat:"Pide və Lahmacun", items:[
    ["Lahmacun pendirli",3.5],["Lahmacun sadə",2.8],["Pide pendirli",4],["Pide toyuqlu",5.5],
    ["Pide sucuklu",5],["Pide qarışıq",5],["Pide qiymalı",6],["Pide quşbaşı",6]
  ]},
  {cat:"Dönərlər", items:[
    ["Şaurma",3.2],["İskəndər dönər",6],["Toyuq dönər",2.5],["Toyuq lavaşda",3],
    ["Basdırma",2.8],["Limuzin dönər",4.8],["Porsion dönər",6.5],["Plov üstü",6.5]
  ]},
  {cat:"Sərin içkilər", items:[
    ["Fanta, Coca Cola, Sprite, Pepsi Stəkan",0.8],
    ["Fanta, Coca Cola, Sprite, Pepsi 0.3L",1.2],
    ["Fanta, Coca Cola, Sprite, Pepsi 0.5L",1.8],
    ["Fanta, Coca Cola, Sprite, Pepsi 1L",3],
    ["Duşes / Tərxun 0.5L",3],["Duşes / Tərxun Stəkan",0.8],["Soyuq çay banka",2],
    ["Cappy 0.5",2],["Cappy 1L",3],["Çöpüli meyvə şirəsi",1],["Kompot",3.5],["Ayran",0.8]
  ]},
  {cat:"Kokteyllar", items:[
    ["Ice Coffee",3.5],["Milkshakes Çiyələk",4.5],["Milkshakes Banan",4.5],
    ["Milkshakes Vanilla",4],["Milkshakes Bounty",5],["Milkshakes Snickers",5],
    ["Milkshakes Oreo",5],["Milkshakes Caramel",5],["Milkshakes Şokolad",5],["Moxito",4]
  ]},
  {cat:"Çay süfrəsi", items:[
    ["Çay stəkan",0.5],["Çay çaynik",2],["Çay şokolad",5],["Çay mürəbbə",5],["Çay dəstgahı",6]
  ]},
  {cat:"Desertlər", items:[
    ["Şəki halvası",5],["Bamiyə",3],["Mindal",5],["Dondurma (3 top)",3],
    ["Qoz mürəbbəsi",5],["Mürəbbə kiçik / böyük",3.5],["Paxlava",1],["Türk paxlavası",0.8]
  ]},
  {cat:"Kofelər", items:[
    ["Kofe sadə",2],["Südlü kofe",3],["Cappucino",2.5],["Latte",2.5],["İsti şokolad",2.5]
  ]},
  {cat:"Setlər", items:[
    ["Burger Set — 2 burger + 2 nuggets + 2 fri + 2 Coca Cola 0.33L",25.5],
    ["Kabab Set — lülə, tikə, antrikot, toyuq kababı, toyuq lüləsi, tərəvəz, semişka, fri, çoban salatı, 2 ədəd qazlı içki",39.5]
  ]}
];

const money = n => n.toFixed(2).replace(".", ",") + " ₼";
const sections = document.getElementById("menuSections");
const cats = document.getElementById("categories");
const cartPanel = document.getElementById("cartPanel");
const cartItems = document.getElementById("cartItems");
const cartTotal = document.getElementById("cartTotal");
const cartCount = document.getElementById("cartCount");
let cart = [];

menu.forEach((group, gi) => {
  const btn = document.createElement("button");
  btn.textContent = group.cat;
  btn.onclick = () => document.getElementById("cat-"+gi).scrollIntoView({behavior:"smooth",block:"start"});
  cats.appendChild(btn);

  const sec = document.createElement("section");
  sec.className = "menu-section";
  sec.id = "cat-"+gi;
  sec.innerHTML = `<h2>${group.cat}</h2><div class="grid"></div>`;
  const grid = sec.querySelector(".grid");

  group.items.forEach(([name, price]) => {
    const item = document.createElement("article");
    item.className = "item";
    item.innerHTML = `<div><div class="item-name">${name}</div><button class="add">+ Səbətə əlavə et</button></div><div class="price">${money(price)}</div>`;
    item.querySelector(".add").onclick = () => addItem(name, price);
    grid.appendChild(item);
  });
  sections.appendChild(sec);
});

function addItem(name, price){
  const found = cart.find(x => x.name === name);
  if(found) found.qty++;
  else cart.push({name,price,qty:1});
  renderCart();
}
function changeQty(name, delta){
  const x = cart.find(i => i.name === name);
  if(!x) return;
  x.qty += delta;
  if(x.qty <= 0) cart = cart.filter(i => i.name !== name);
  renderCart();
}
function renderCart(){
  cartItems.innerHTML = cart.length ? cart.map(x => `
    <div class="cart-row">
      <div>${x.name}<br><small>${money(x.price)}</small></div>
      <div class="qty"><button onclick='changeQty(${JSON.stringify(x.name)},-1)'>−</button> ${x.qty} <button onclick='changeQty(${JSON.stringify(x.name)},1)'>+</button></div>
      <strong>${money(x.price*x.qty)}</strong>
    </div>`).join("") : "<p>Səbət boşdur.</p>";
  const total = cart.reduce((s,x)=>s+x.price*x.qty,0);
  const count = cart.reduce((s,x)=>s+x.qty,0);
  cartTotal.textContent = money(total);
  cartCount.textContent = count;
}
document.getElementById("openCart").onclick=()=>cartPanel.classList.add("show");
document.getElementById("closeCart").onclick=()=>cartPanel.classList.remove("show");
cartPanel.onclick=e=>{if(e.target===cartPanel)cartPanel.classList.remove("show")};

document.getElementById("whatsappOrder").onclick=()=>{
  if(!cart.length){alert("Əvvəlcə menyudan məhsul seçin.");return}
  if(WHATSAPP_NUMBER.includes("X")){alert("script.js faylında WHATSAPP_NUMBER hissəsinə restoranın WhatsApp nömrəsini yazın.");return}
  const name=document.getElementById("customerName").value.trim();
  const address=document.getElementById("customerAddress").value.trim();
  const total=cart.reduce((s,x)=>s+x.price*x.qty,0);
  let text="Salam, Lavanda Restorandan sifariş etmək istəyirəm.%0A%0A";
  cart.forEach(x=>text+=`• ${x.name} — ${x.qty} ədəd — ${money(x.price*x.qty)}%0A`);
  text+=`%0ACəmi: ${money(total)}%0AAd: ${name||"Qeyd edilməyib"}%0AÜnvan: ${address||"Qeyd edilməyib"}`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${text}`,"_blank");
};
renderCart();
